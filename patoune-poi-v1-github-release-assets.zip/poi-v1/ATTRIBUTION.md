# Patoune Rando department POI catalogue

Source: © OpenStreetMap contributors, licensed under the Open Database License (ODbL).

Hiking-essential categories: cities/towns/villages/hamlets, peaks, viewpoints, shelters, camping, restaurants/cafes, parking, picnic areas, drinking water, springs, museums, castles and monuments.
