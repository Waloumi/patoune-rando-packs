# Patoune Rando — department POI catalogue v1

This catalogue contains 101 compressed GeoJSON FeatureCollections, one per French department.
Each file carries hiking-essential named locations from OpenStreetMap: cities/towns/villages/hamlets, peaks, viewpoints, shelters, campsites, restaurants/cafes, parking, picnic areas, drinking water, springs, museums, castles and monuments.

## GitHub Release publication

1. Create `https://github.com/Waloumi/patoune-rando-packs`.
2. Install and authenticate the [GitHub CLI](https://cli.github.com/): `gh auth login`.
3. From this folder run `./publish-github-release.sh`.

It creates a `poi-v1` Release and uploads `catalogue.json`, attribution, and all 101 assets. Each `catalogue.json` `file` field matches exactly one GitHub Release asset.

## Attribution

© OpenStreetMap contributors, licensed under the Open Database License (ODbL). Retain `ATTRIBUTION.md` in the release.
