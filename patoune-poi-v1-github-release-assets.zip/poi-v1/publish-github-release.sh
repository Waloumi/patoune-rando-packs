#!/usr/bin/env bash
# One-time publisher. Run after creating github.com/Waloumi/patoune-rando-packs
set -euo pipefail
REPO='Waloumi/patoune-rando-packs'
TAG='poi-v1'
HERE="$(cd "$(dirname "$0")" && pwd)"
gh auth status
gh release create "$TAG" --repo "$REPO" --title 'Patoune department POI catalogue v1' --notes '101 compressed department POI shards. © OpenStreetMap contributors, ODbL.'
gh release upload "$TAG" "$HERE"/release-assets/* --repo "$REPO" --clobber
